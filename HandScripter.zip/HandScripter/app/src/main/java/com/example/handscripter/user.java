package com.example.handscripter;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class user extends AppCompatActivity {
    Toolbar toolbar;
    ImageButton camera2, user2,home2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user);

        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        camera2 = findViewById(R.id.camera2);
        camera2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tocamera;
                tocamera= new Intent(user.this, camera.class);
                startActivities(new Intent[]{tocamera});
            }
        });

        user2 = findViewById(R.id.user2);
        user2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent user;
                user = new Intent(user.this,user.class);
                startActivities(new Intent[]{user});
            }
        });

        home2 = findViewById(R.id.home2);
        home2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home;
                home = new Intent(user.this, MainActivity.class);
                startActivities(new Intent[]{home});
            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.privacy){

            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://fitnessclubhamza.blogspot.com/2024/05/privacy-policy-for-handscripter.html"));
            startActivity(intent);
            return true;
        }
        if (id == R.id.term){

            Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://fitnessclubhamza.blogspot.com/2024/05/terms-and-conditions-for-handscripter.html"));
            startActivity(intent);

            return true;
        }
        if (id == R.id.rate){

            try {
                startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id=" + getPackageName())));

            }catch (Exception ex){

                startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("http://play.google.come/store/apps/details?id=" + getPackageName())));


            }

            return true;
        }
        if (id == R.id.more){

            Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(""));
            startActivity(intent);

            return true;
        }
        if (id == R.id.share){

            Intent myIntent = new Intent(Intent.ACTION_SEND);
            myIntent.setType("text/plain");
            String sharebody = "This is the best App for HandWriting Recognition \n This App provide 95% Accuracy\n Free App Download Now \n"+"https://play.google.com/store/apps/details?id=com.example.handscripter&hl=en";
            String sharehub = "HandScripter";
            myIntent.putExtra(Intent.EXTRA_SUBJECT,sharehub);
            myIntent.putExtra(Intent.EXTRA_TEXT,sharebody);
            startActivity(Intent.createChooser(myIntent,"share using"));

            return true;
        }

        return true;
    }
}