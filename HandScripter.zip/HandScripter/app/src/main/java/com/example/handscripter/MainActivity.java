package com.example.handscripter;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.TooltipCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;
    ImageButton camera, gallery, btncamera1, btnuser,btnhome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

            Toolbar toolbar=findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);

        camera = findViewById(R.id.camera);
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tocamera;
                tocamera= new Intent(MainActivity.this, camera.class);
                startActivities(new Intent[]{tocamera});
            }
        });

        gallery = findViewById(R.id.gallery);
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent togallery;
                togallery = new Intent(MainActivity.this, gallery.class);
                startActivities(new Intent[]{togallery});
            }
        });

        btncamera1 = findViewById(R.id.btncamera1);
        btncamera1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tocamera;
                tocamera= new Intent(MainActivity.this, camera.class);
                startActivities(new Intent[]{tocamera});
            }
        });

        btnuser = findViewById(R.id.btnuser);
        btnuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent user;
                user = new Intent(MainActivity.this,user.class);
                startActivities(new Intent[]{user});
            }
        });

        btnhome = findViewById(R.id.btnhome);
        btnhome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home;
                home = new Intent(MainActivity.this, MainActivity.class);
                startActivities(new Intent[]{home});
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.privacy){

            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://fitnessclubhamza.blogspot.com/2024/05/privacy-policy-for-handscripter.html"));
            startActivity(intent);
            return true;
        }
        if (id == R.id.term){

            Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://fitnessclubhamza.blogspot.com/2024/05/terms-and-conditions-for-handscripter.html"));
            startActivity(intent);

            return true;
        }
        if (id == R.id.rate){

            try {
                startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id=" + getPackageName())));

            }catch (Exception ex){

                startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("http://play.google.come/store/apps/details?id=" + getPackageName())));


            }

            return true;
        }
        if (id == R.id.more){

            Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(""));
            startActivity(intent);

            return true;
        }
        if (id == R.id.share){

            Intent myIntent = new Intent(Intent.ACTION_SEND);
            myIntent.setType("text/plain");
            String sharebody = "This is the best App for HandWriting Recognition \n This App provide 95% Accuracy\n Free App Download Now \n"+"https://play.google.com/store/apps/details?id=com.example.handscripter&hl=en";
            String sharehub = "HandScripter";
            myIntent.putExtra(Intent.EXTRA_SUBJECT,sharehub);
            myIntent.putExtra(Intent.EXTRA_TEXT,sharebody);
            startActivity(Intent.createChooser(myIntent,"share using"));

            return true;
        }

        return true;
    }
}